文件夹1、2、3分别装有

* 文件夹1
  * LinkedListSparseBoundedGrid.java
  * SparseGridRunner.java
* 文件夹2
  * HashMapSparseBoundedGrid.java
  * SparseGridRunner.java
* 文件夹3
  - UnboundedGrid2.java
  - SparseGridRunner.java

用SparseGridRunner.java来运行测试