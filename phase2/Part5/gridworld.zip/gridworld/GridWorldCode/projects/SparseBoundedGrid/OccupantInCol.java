/* 
 * @author Zhengtao Wu
 */

/**
 * <code>OccupantInCol</code> <br />
 * The helper class for LinkedListSparseBoundedGrid
 */
public class OccupantInCol {
	// The occupant object
	private Object occupant;
	// The column number of the occupant
	private int col;
	
	// Constructor
	public OccupantInCol(Object obj, int colNum) {
		occupant = obj;
		col = colNum;
	}
	
	// Get occupant
	public Object getOccupant() {
		return occupant;
	}
	
	// Set occupant
	public void setOccupant(Object obj) {
		occupant = obj;
	}
	
	// Get the column number of the occupant
	public int getColNum() {
		return col;
	}
}
